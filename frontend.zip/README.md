### Air UI React Admin Template Preview ###
https://react.airui.cloud

### Documentation ###
Please read documentation here https://docs.sellpixels.com

### Quick Start ###
* Install node.js: https://nodejs.org​
* Install yarn package manager: https://yarnpkg.com/​
* Install node modules by running terminal command `yarn install`
* Run the app `yarn start`
* Or build production app `yarn build`

### Support ###
Use GitHub Issues for tracking bugs and creating new feature requests or write to [support@sellpixels.com](mailto:support@sellpixels.com).
